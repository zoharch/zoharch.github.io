package com.zohar.famelycontentprovider;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Ronit on 03/11/2017.
 */

public class DBHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final class Famely {
        private final static String TABLE_NANE = DBContract.Famely.TABLE_NAME;
        private final static String CREATE_TABLE = "CREATE TABLE " + Famely.TABLE_NANE +
                " ( " + DBContract.Famely.ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " +
                DBContract.Famely.FIRST_NAME + " TEXT NOT NULL , " +
                DBContract.Famely.LAST_NAME + " TEXT NOT NULL  , " +
                DBContract.Famely.FAMELY_ROLE + " TEXT NOT NULL , " +
                DBContract.Famely.PERSON_ID + " TEXT NOT NULL " +
                " ) ";
    }
    private static final class Person {
        private final static String TABLE_NANE = DBContract.Person.TABLE_NAME;
        private final static String CREATE_TABLE = "CREATE TABLE " + Person.TABLE_NANE +
                " ( " + DBContract.Person.ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " +
                DBContract.Person.AGE + " INTEGER NOT NULL , " +
                DBContract.Person.HEIGHT + " INTEGER NOT NULL , " +
                DBContract.Person.WEIGHT + " INTEGER NOT NULL " +
                " ) ";
    }

    public DBHelper(Context context) {
        super(context, DBContract.DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Famely.CREATE_TABLE);
        db.execSQL(Person.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
