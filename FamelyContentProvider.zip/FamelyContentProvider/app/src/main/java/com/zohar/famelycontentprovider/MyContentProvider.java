package com.zohar.famelycontentprovider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import static android.content.ContentValues.TAG;

/**
 * http://www.mysamplecode.com/2012/11/android-database-content-provider.html
 */

public class MyContentProvider extends ContentProvider {

    private DBHelper dbHelper;
    private static final int ALL_PERSONS = 1;
    private static final int SINGLE_PERSON = 2;
    // authority is the symbolic name of your provider
    // To avoid conflicts with other providers, you should use
    // Internet domain ownership (in reverse) as the basis of your provider authority.
    private static final String AUTHORITY = "com.zohar.famelycontentprovider.MyContentProvider";
    // create content URIs from the authority by appending path to database table
    public static final Uri CONTENT_URI =
            Uri.parse("content://" + AUTHORITY + "/persons");
    // a content URI pattern matches content URIs using wildcard characters:
    // *: Matches a string of any valid characters of any length.
    // #: Matches a string of numeric characters of any length.
    private static final UriMatcher uriMatcher;
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTHORITY, "persons", ALL_PERSONS);
        uriMatcher.addURI(AUTHORITY, "persons/#", SINGLE_PERSON);
    }

    // system calls onCreate() when it starts up the provider.
    @Override
    public boolean onCreate() {
        Log.d(TAG, "onCreate: contentprovider creats new dbHelper");
        // get access to the database helper
        dbHelper = new DBHelper(getContext());
        return false;
    }

    //Return the MIME type corresponding to a content URI

    /**
     * The MIME types returned by ContentProvider.getType have two distinct parts:
     type/subType
     The type portion indicates the well known type that is returned for a given URI by the ContentProvider,
     as the query methods can only return Cursors the type should always be:
     vnd.android.cursor.dir for when you expect the Cursor to contain 0 through infinity items
     or
     vnd.android.cursor.item for when you expect the Cursor to contain 1 item
     The subType portion can be either a well known subtype or something unique to your application.
     So when using a ContentProvider you can customize the second subType portion of the MIME type,
     but not the first portion. e.g a valid MIME type for your apps ContentProvider could be:
     vnd.android.cursor.dir/vnd.myexample.whatever
     The MIME type returned from a ContentProvider can be used by an Intent to determine which activity
     to launch to handle the data retrieved from a given URI.
     * @param uri
     * @return
     */
    @Override
    public String getType(Uri uri) {

        switch (uriMatcher.match(uri)) {
            case ALL_PERSONS:
                return "vnd.android.cursor.dir/person";
            case SINGLE_PERSON:
                return "vnd.android.cursor.item/person";
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
    }

    // The insert() method adds a new row to the appropriate table, using the values
    // in the ContentValues argument. If a column name is not in the ContentValues argument,
    // you may want to provide a default value for it either in your provider code or in
    // your database schema.
    //to insert cirectly one should suply uri for ALL_PERSONS ===zohar
    @Override
    public Uri insert(Uri uri, ContentValues values) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        switch (uriMatcher.match(uri)) {
            case ALL_PERSONS:
                //do nothing
                break;
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
        long id = db.insert(DBContract.Person.TABLE_NAME, null, values);
        Log.d(TAG, "insert: id: " + id);
        getContext().getContentResolver().notifyChange(uri, null);
        return Uri.parse(CONTENT_URI + "/" + id);

    }

    /**
     *  The query() method must return a Cursor object, or if it fails,
     throw an Exception. If you are using an SQLite database as your data storage,
     you can simply return the Cursor returned by one of the query() methods of the
     SQLiteDatabase class. If the query does not match any rows, you should return a
     Cursor instance whose getCount() method returns 0. You should return null only
     if an internal error occurred during the query process.
      * @param uri
     * @param projection
     * @param selection
     * @param selectionArgs
     * @param sortOrder
     * @return
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        Log.d(TAG, "30-----query: Mycontentprovider got query and know it deliver it to the DB");
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
        queryBuilder.setTables(DBContract.Person.TABLE_NAME);

        switch (uriMatcher.match(uri)) {
            case ALL_PERSONS:
                Log.d(TAG, "32------query: switch for ALL_USERS");
                //do nothing
                break;
            case SINGLE_PERSON:
                String id = uri.getPathSegments().get(1);
                Log.d(TAG, "query: uri for SINGLE_PERSON id = " + id);
                queryBuilder.appendWhere(DBContract.Person.ID + "=" + id);
                break;
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }

        Cursor cursor = queryBuilder.query(db, projection, selection,
                selectionArgs, null, null, sortOrder);
        Log.d(TAG, "34------query: after the query to the DB");
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;

    }
    // The delete() method deletes rows based on the seletion or if an id is
    // provided then it deleted a single row. The methods returns the numbers
    // of records delete from the database. If you choose not to delete the data
    // physically then just update a flag here.
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        switch (uriMatcher.match(uri)) {
            case ALL_PERSONS:
                //do nothing
                break;
            case SINGLE_PERSON:
                String id = uri.getPathSegments().get(1);
                selection = DBContract.Person.ID + "=" + id
                        + (!TextUtils.isEmpty(selection) ?
                        " AND (" + selection + ')' : "");
                break;
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
        int deleteCount = db.delete(DBContract.Person.TABLE_NAME, selection, selectionArgs);
        getContext().getContentResolver().notifyChange(uri, null);
        return deleteCount;
    }

    // The update method() is same as delete() which updates multiple rows
    // based on the selection or a single row if the row id is provided. The
    // update method returns the number of updated rows.
    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        switch (uriMatcher.match(uri)) {
            case ALL_PERSONS:
                //do nothing
                break;
            case SINGLE_PERSON:
                String id = uri.getPathSegments().get(1);
                selection = DBContract.Person.ID + "=" + id
                        + (!TextUtils.isEmpty(selection) ?
                        " AND (" + selection + ')' : "");
                break;
            default:
                throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
        int updateCount = db.update(DBContract.Person.TABLE_NAME, values, selection, selectionArgs);
        getContext().getContentResolver().notifyChange(uri, null);
        return updateCount;
    }

}
