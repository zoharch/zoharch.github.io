package com.zohar.famelycontentprovider;

public final class DBContract {

    public final static String DB_NAME = "FAMELY_DB";

    public static class Famely {
        public static final String TABLE_NAME = "FAMELY_TABLE";
        public static final String ID = "_id";
        public static final String FIRST_NAME = "FIRST_NAME";
        public static final String LAST_NAME = "LAST_NAME";
        public static final String FAMELY_ROLE = "FAMELY_ROLE";
        public static final String PERSON_ID = "PERSON_ID";
    }
    public static class Person {
        public static final String TABLE_NAME = "PERSOM_TABLE";
        public static final String ID = "_id";
        public static final String AGE = "AGE";
        public static final String WEIGHT = "WEIGHT";
        public static final String HEIGHT = "HEIGHT";

    }
}
