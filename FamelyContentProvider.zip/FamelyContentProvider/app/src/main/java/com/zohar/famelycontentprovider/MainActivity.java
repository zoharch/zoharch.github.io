package com.zohar.famelycontentprovider;

import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements android.app.LoaderManager.LoaderCallbacks<Cursor> {
    private static final String TAG = "--------" + MainActivity.class.getName();
    ListView listView;
    private ArrayList <Person> persons;
    private CursorAdapter dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.activity_main_list_view);

        persons = new ArrayList<Person>();

        //dbQuery();
        //Log.d(TAG, "onCreate: " + persons);
        TextView empty = (TextView) findViewById(R.id.empty);
        listView.setEmptyView(empty);
        Log.d(TAG, "10-----onCreate: calling loadmanager");
        getLoaderManager().initLoader(0, null, this);
        createAdapterWithNullCursor();
        listView.setAdapter(dataAdapter);
    }

    private void createAdapterWithNullCursor() {

        class Holder {
            TextView firstTV;
            TextView secondTV;
        }

        dataAdapter = new CursorAdapter(this,null,false) {
            @Override
            public View newView(Context context, Cursor cursor, ViewGroup parent) {
                Log.d(TAG, "Cursor adapter--newView: inside cursur adapter (inflate)");
                View view = LayoutInflater.from(context).inflate(R.layout.adapter_layout,parent,false);
                TextView firstTV = (TextView) view.findViewById(R.id.adapter_layout_first_text_view);
                TextView secondTV = (TextView) view.findViewById(R.id.adapter_layout_second_text_view);
                Holder holder = new Holder();
                holder.firstTV = firstTV;
                holder.secondTV = secondTV;
                view.setTag(holder);
                return view;
            }

            @Override
            public void bindView(View view, Context context, Cursor cursor) {
                Log.d(TAG, "bindView: inside cursur adapter");
                Holder holder = (Holder) view.getTag();
                Log.d(TAG, "bindView in the custom adapter: reading from the cursor loader");
                holder.firstTV.setText(cursor.getInt(cursor.getColumnIndex(DBContract.Person.ID))+"");
                holder.secondTV.setText(String.valueOf(cursor.getInt(cursor.getColumnIndex(DBContract.Person.AGE))));
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();

        //Starts a new or restarts an existing Loader in this manager
    }

    private void insertSomeValues() {
        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Log.d(TAG, "insertSomeValues: entering to the insert methode");
        ContentValues values = new ContentValues();
        Random random = new Random();
        for (int index = 10; index < 98; index++) {
            Log.d(TAG, "insertSomeValues: " + index);
            values.put(DBContract.Person.AGE,11);
            values.put(DBContract.Person.HEIGHT,40);
            values.put(DBContract.Person.WEIGHT,20+random.nextInt(80));
            db.insert(DBContract.Person.TABLE_NAME,null,values);
        }
        db.close();
    }

    private void dbQuery() {

        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String columns[] = { DBContract.Person.ID, DBContract.Person.AGE,DBContract.Person.HEIGHT };
        String where = DBContract.Person.ID + ">?"; // You add column as per your Query
        String[] whereArgs = new String[]{"0"};
        String orderBy = DBContract.Person.AGE + " DESC ";

        Cursor cursor = db.query(DBContract.Person.TABLE_NAME, columns, where, whereArgs, null, null, orderBy, null);

        cursor.moveToFirst();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex(DBContract.Person.ID));
            int age = cursor.getInt(cursor.getColumnIndex(DBContract.Person.AGE));
            persons.add(new Person(id,age));
        }
    }


    @Override
    public android.content.Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Log.d(TAG, "20------onCreateLoader: loader calls content provide");
        String[] projection = {
                DBContract.Person.ID,
                DBContract.Person.AGE};
        CursorLoader cursorLoader = new CursorLoader(this,
                MyContentProvider.CONTENT_URI, projection, null, null, null);
        Log.d(TAG, "30 --- onCreateLoader: loader  created and sent SQL query");
        return cursorLoader;
    }

    @Override
    public void onLoadFinished(android.content.Loader<Cursor> loader, Cursor data) {
        Log.d(TAG, "50 ------ onLoadFinished: loader finish , calling update display");
        dataAdapter.swapCursor(data);
      }

    @Override
    public void onLoaderReset(android.content.Loader<Cursor> loader) {
        // This is called when the last Cursor provided to onLoadFinished()
        // above is about to be closed.  We need to make sure we are no
        // longer using it.
        dataAdapter.swapCursor(null);

    }

    public void insertBtn(View view) {
        Random random = new Random();
        int age = random.nextInt(100);
        int height = random.nextInt(100);
        int weight = random.nextInt(100);
        ContentValues values = new ContentValues();
        values.put(DBContract.Person.AGE,age);
        values.put(DBContract.Person.HEIGHT,height);
        values.put(DBContract.Person.WEIGHT,weight);
        getContentResolver().insert(MyContentProvider.CONTENT_URI,values);
    }
}
