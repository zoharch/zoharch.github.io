package com.zohar.famelycontentprovider;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;

/**
 * Created by Ronit on 03/11/2017.
 */

    class MyCustomAdapter extends ArrayAdapter {
    Context context;
    ArrayList<Person> persons;

    public MyCustomAdapter(Context context, ArrayList<Person> persons) {
        super(context,R.layout.adapter_layout,persons);
        this.context = context;
        this.persons = persons;
    }
    private class ViewHolder {
        TextView first_TV;
        TextView second_TV;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            //Log.d(TAG, "getView: convertview is null - inflating");
            convertView = LayoutInflater.from(context).inflate(R.layout.adapter_layout,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.first_TV = (TextView) convertView.findViewById(R.id.adapter_layout_first_text_view);
            viewHolder.second_TV = (TextView) convertView.findViewById(R.id.adapter_layout_second_text_view);
            convertView.setTag(viewHolder);
            //Log.d(TAG, "getView: view holder->" + viewHolder.toString());
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            //Log.d(TAG, "getView: convert view is not null");
        }
        int color = Color.argb(120,50,50,50);
        int id = persons.get(position).getId();
        int age = persons.get(position).getAge();
        if (age == 97) color = Color.parseColor("YELLOW");
        if (age == 98 ) color = Color.parseColor("#FF00FF00");
        if (age == 95 ) color = Color.parseColor("BLUE");
        Log.d(TAG, "getView: AGE: " + age + " , color: " + color);
        viewHolder.first_TV.setText( id + "");
        viewHolder.second_TV.setText( age + "");
        viewHolder.second_TV.setBackgroundColor(color);
        return convertView;
    }
}
