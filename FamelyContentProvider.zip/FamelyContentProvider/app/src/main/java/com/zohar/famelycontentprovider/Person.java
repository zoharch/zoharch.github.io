package com.zohar.famelycontentprovider;

/**
 * Created by Ronit on 03/11/2017.
 */
public class Person {
    int id;
    int age;
    Person(int id,int age){
        this.id = id;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return id + ", " + age;
    }
}